package com.service;


@org.springframework.stereotype.Service
public class Service {

}
