package com.repository;

import java.util.ArrayList;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.Quote;

@Repository
public interface QuoteRepository extends JpaRepository<Quote, String> {
	
	ArrayList<Quote> findByAuto(String auto);
	
    Quote findByQid(String qid);


}
