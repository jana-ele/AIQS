package com.controller;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.entity.Auto;
import com.entity.Buy;
import com.entity.Driver;
import com.entity.Quote;
import com.repository.AutoRepository;
import com.repository.BuyRepository;
import com.repository.DriverRepository;
import com.repository.QuoteRepository;
import com.service.Service;

@Controller
public class ProjectController {

	@Autowired
	AutoRepository arepo;

	@Autowired
	DriverRepository drepo;

	@Autowired
	QuoteRepository qrepo;
	
	@Autowired
	BuyRepository brepo;

	@Autowired
	Service s;

	String n;

	@GetMapping("/add/auto1")
	public String add1(Auto auto, Model model) {

		model.addAttribute("auto", new Auto());
		return "addauto";
	}

	@PostMapping("/add/auto")
	public String add(Auto auto, Model model) {

		arepo.save(auto);
		model.addAttribute("msg", "Add Success");
		return "home";
	}

	@GetMapping("/add/driver1")
	public String adddriver(Driver driver, Model model) {

		model.addAttribute("driver", new Driver());
		return "adddriver";
	}

	@PostMapping("/add/driver")
	public String adddriver1(Driver driver, Model model) {

		Auto a = null;
		a = arepo.findBytype(driver.getVname());
		if (a != null) {
			drepo.save(driver);
			model.addAttribute("msg", "Add Success");
			return "home";
		}
		model.addAttribute("error", "Vehicle does not exist");
		return "adddriver";
	}

	@GetMapping("/back")
	public String back() {

		return "home";

	}

	@GetMapping("/viewdriver")
	public String viewdriver(Model model) {

		ArrayList<Driver> ms = new ArrayList<Driver>();
		ms = (ArrayList<Driver>) drepo.findAll();
		model.addAttribute("ms", ms);
		return "viewdriver";
	}

	@GetMapping("/editdriver/{email}")
	public String editdriver(Model model, @PathVariable String email) {
		Driver d = drepo.findByEmail(email);
		n = d.getVname();
		model.addAttribute("email", email);
		model.addAttribute("n", n);
		model.addAttribute("driver", new Driver());
		return "editdriver";

	}

	@PostMapping("/edit/driver")
	public String edit(Model model, Driver d) {
		drepo.save(d);
		model.addAttribute("msg", "Edit Success");
		return "home";
	}

	@GetMapping("/deletedriver/{email}")
	public String delete(@PathVariable String email, Model model) {
		Driver d = null;
		d = drepo.findByEmail(email);

		drepo.delete(d);
		model.addAttribute("msg", "Delete Success");
		return "home";

	}

	@GetMapping("/allviewquotes")
	public String viewq(Model model) {
		ArrayList<Quote> ms = new ArrayList<Quote>();
		ms = (ArrayList<Quote>) qrepo.findAll();
		System.out.println(ms);
		model.addAttribute("ms", ms);
		return "viewquote";
	}
	
	@GetMapping("/buyquote")
	public String buy()
	{
		return "verify";
	}
	
	@PostMapping("/verify")
	public String verify(@RequestParam("email")String email,Model model)
	{
	  Driver d=null;
	  d=drepo.findByEmail(email);
	  if(d!=null) {
		  ArrayList<Quote> q= new ArrayList<Quote>();
		  q = (ArrayList<Quote>) qrepo.findByAuto(d.getVname());
		  model.addAttribute("ms",q);
		  return "verifyquotes";
	  }
	  model.addAttribute("error","Email ID does not exist");
	  return "verify";
	}
	
    @GetMapping("/Buy/{qid}")
    public String buy(@PathVariable String qid,Model model) {
        Quote q=null;
    	q=qrepo.findByQid(qid);
    	Buy b=new Buy();
    	b.setAuto(q.getAuto());
    	b.setInfo(q.getInfo());
    	b.setP(q.getP());
    	b.setQid(q.getQid());
    	brepo.save(b);
    	model.addAttribute("msg", "Buy Success");
    	return "home";
    }
}
