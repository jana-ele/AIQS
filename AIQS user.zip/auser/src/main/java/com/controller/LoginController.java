package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.entity.User;
import com.repository.UserRepository;

@Controller
public class LoginController {

	@Autowired
	UserRepository userRepo;
    
	String email1;
	
	@GetMapping("/")

	public String checkMVC() {

		return "login";

	}

	@GetMapping("/home")

	public String check(Model model) {

		return "homePage";

	}

	@PostMapping("/login")

	public String loginHomePage(@RequestParam("email") String email,

			@RequestParam("password") String password, Model model) {

		User p = null;

		p = userRepo.findByEmailAndPassword(email, password);

		if (p != null) {
            email1=email;
			return "home";

		}
		model.addAttribute("error", "Incorrect Username or password");
		return "login";
	}

	@GetMapping("/register")

	public String goToReistrationPage(Model model) {
		model.addAttribute("user", new User());

		return "register";

	}

	@PostMapping("/registerdone")
	public String register(User u) {
		userRepo.save(u);
		return "login";
	}
	
	@GetMapping("/changepin")
	public String changepin() {
		
		return "changepin";
	}
	
	@GetMapping("/logout")
	public String logout() {
		
		return "login";
	}
	
	@PostMapping("/changepin")
	public String change(Model model,@RequestParam("password") String p,@RequestParam("password1") String p1,@RequestParam("password2") String p2) {
		
	 User l=null;
	 l=userRepo.findByEmailAndPassword(email1, p);
	 System.out.println(p);
	 System.out.println(p1);
	 System.out.println(p2);
	 if(l!=null&&p1.equals(p2)&&!p1.equals(p)) {
		 l.setPassword(p1);
		 userRepo.save(l);
		 return "login";
	 }
	 
	 if(l==null) {
		 model.addAttribute("error","Entered wrong password");
		 return "changepin";
	 }
	 if(p1!=p2) {
		 model.addAttribute("error","New password and confirm password do not match");
		 return "changepin";
	 }
	 return "home";
	}


}
