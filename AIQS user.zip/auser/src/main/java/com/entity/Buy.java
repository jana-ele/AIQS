package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Buy {

	public Buy() {
		super();
	}

	public Buy(String qid, String auto, String p, String info) {
		super();
		this.qid = qid;
		this.auto = auto;
		this.p = p;
		this.info = info;
	}

	@Id @Column(name="QuoteId") 
	private String qid;
	
	@Column(name="Vehicle Name") 
	private String auto;
	
	@Column (name ="Premium")
	private String p;
	
	@Column (name ="info")
	private String info;

	public String getQid() {
		return qid;
	}

	public void setQid(String qid) {
		this.qid = qid;
	}

	public String getAuto() {
		return auto;
	}

	public void setAuto(String auto) {
		this.auto = auto;
	}

	public String getP() {
		return p;
	}

	public void setP(String p) {
		this.p = p;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Override
	public String toString() {
		return "Quote [qid=" + qid + ", auto=" + auto + ", p=" + p + ", info=" + info + "]";
	}
}
