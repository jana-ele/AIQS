package com.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



@Entity
@Table(name="vehicle")
public class Auto {
	


	public Auto() {
		super();
	}

	public Auto(String noId, String type, String chechisNumber, String engineNumber, String year) {
		super();
		this.noId = noId;
		this.type = type;
		this.chechisNumber = chechisNumber;
		this.engineNumber = engineNumber;
		this.year = year;
	}

	@Id @Column(name="NoId") 
	private String noId;
	
	@Column(name="Vehicle Name") 
	private String type;
	
	@Column (name ="chechisNumber")
	private String chechisNumber;
	
	@Column (name ="engineNumber")
	private String engineNumber;
	
	@Column (name ="YearBought")
	private String year;

	public String getNoId() {
		return noId;
	}

	public void setNoId(String noId) {
		this.noId = noId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getChechisNumber() {
		return chechisNumber;
	}

	public void setChechisNumber(String chechisNumber) {
		this.chechisNumber = chechisNumber;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Auto [noId=" + noId + ", type=" + type + ", chechisNumber=" + chechisNumber + ", engineNumber="
				+ engineNumber + ", year=" + year + "]";
	}

	

	
}
